export interface ImageState {
  file: File | null;
  preview: string | null;
}

export * from './api';